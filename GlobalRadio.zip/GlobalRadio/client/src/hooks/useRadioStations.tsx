import { useQuery } from "@tanstack/react-query";
import { RadioStation } from "@/types/radio";

const API_BASE = "https://de1.api.radio-browser.info";

export function useRadioStations(countryCode: string) {
  return useQuery<RadioStation[]>({
    queryKey: ["radio-stations", countryCode],
    queryFn: async () => {
      const response = await fetch(
        `${API_BASE}/json/stations/bycountrycodeexact/${countryCode}?hideBroken=true&order=clickcount&reverse=true&limit=50`,
        {
          headers: {
            "User-Agent": "VintageRadioApp/1.0",
          },
        }
      );

      if (!response.ok) {
        throw new Error("Failed to fetch radio stations");
      }

      const stations = await response.json();
      return stations.filter((station: RadioStation) => station.lastcheckok === 1);
    },
    staleTime: 5 * 60 * 1000, // 5 minutes
  });
}

export function useStationsByLanguage(language: string) {
  return useQuery<RadioStation[]>({
    queryKey: ["radio-stations-language", language],
    queryFn: async () => {
      const response = await fetch(
        `${API_BASE}/json/stations/bylanguage/${language}?hideBroken=true&order=clickcount&reverse=true&limit=30`,
        {
          headers: {
            "User-Agent": "VintageRadioApp/1.0",
          },
        }
      );

      if (!response.ok) {
        throw new Error("Failed to fetch radio stations");
      }

      const stations = await response.json();
      return stations.filter((station: RadioStation) => station.lastcheckok === 1);
    },
    staleTime: 5 * 60 * 1000,
  });
}
