import { useState, useRef, useEffect } from "react";
import { RadioStation, RadioState } from "@/types/radio";

export function useRadioPlayer() {
  const audioRef = useRef<HTMLAudioElement>(null);
  const [radioState, setRadioState] = useState<RadioState>({
    isPlaying: false,
    currentStation: null,
    volume: 70,
    isLoading: false,
    isPowered: true,
  });

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = radioState.volume / 100;
    }
  }, [radioState.volume]);

  const selectStation = (station: RadioStation) => {
    setRadioState(prev => ({
      ...prev,
      currentStation: station,
      isPlaying: false,
    }));

    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
    }
  };

  const playStation = async () => {
    if (!radioState.currentStation || !audioRef.current || !radioState.isPowered) return;

    try {
      setRadioState(prev => ({ ...prev, isLoading: true }));
      
      audioRef.current.src = radioState.currentStation.url_resolved;
      audioRef.current.load();
      
      await audioRef.current.play();
      
      setRadioState(prev => ({ 
        ...prev, 
        isPlaying: true, 
        isLoading: false 
      }));

      // Register station click for analytics (optional)
      fetch(`https://de1.api.radio-browser.info/json/url/${encodeURIComponent(radioState.currentStation.stationuuid)}`, {
        method: "POST",
        headers: { "User-Agent": "VintageRadioApp/1.0" },
      }).catch(() => {}); // Ignore errors for analytics

    } catch (error) {
      console.error("Error playing station:", error);
      setRadioState(prev => ({ 
        ...prev, 
        isPlaying: false, 
        isLoading: false 
      }));
    }
  };

  const stopStation = () => {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
    }
    setRadioState(prev => ({ ...prev, isPlaying: false }));
  };

  const setVolume = (volume: number) => {
    setRadioState(prev => ({ ...prev, volume }));
  };

  const togglePower = () => {
    setRadioState(prev => {
      const newPowered = !prev.isPowered;
      if (!newPowered && prev.isPlaying) {
        if (audioRef.current) {
          audioRef.current.pause();
        }
        return { ...prev, isPowered: newPowered, isPlaying: false };
      }
      return { ...prev, isPowered: newPowered };
    });
  };

  const selectNextStation = (stations: RadioStation[]) => {
    if (!stations.length || !radioState.isPowered) return;
    
    const currentIndex = radioState.currentStation 
      ? stations.findIndex(s => s.stationuuid === radioState.currentStation?.stationuuid)
      : -1;
    
    const nextIndex = currentIndex >= stations.length - 1 ? 0 : currentIndex + 1;
    selectStation(stations[nextIndex]);
  };

  const selectPreviousStation = (stations: RadioStation[]) => {
    if (!stations.length || !radioState.isPowered) return;
    
    const currentIndex = radioState.currentStation 
      ? stations.findIndex(s => s.stationuuid === radioState.currentStation?.stationuuid)
      : -1;
    
    const prevIndex = currentIndex <= 0 ? stations.length - 1 : currentIndex - 1;
    selectStation(stations[prevIndex]);
  };

  return {
    audioRef,
    radioState,
    selectStation,
    selectNextStation,
    selectPreviousStation,
    playStation,
    stopStation,
    setVolume,
    togglePower,
  };
}
