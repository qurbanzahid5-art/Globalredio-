import { VintageRadio } from "@/components/radio/VintageRadio";

export default function RadioPage() {
  return <VintageRadio />;
}
