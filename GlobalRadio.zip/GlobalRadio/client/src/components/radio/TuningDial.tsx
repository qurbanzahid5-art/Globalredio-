import { useState } from "react";
import { RadioStation } from "@/types/radio";

interface TuningDialProps {
  stations: RadioStation[];
  currentStation: RadioStation | null;
  onStationSelect: (station: RadioStation) => void;
  isPowered: boolean;
}

export function TuningDial({ stations, currentStation, onStationSelect, isPowered }: TuningDialProps) {
  const [rotation, setRotation] = useState(45);

  const handleDialClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!isPowered || stations.length === 0) return;

    const rect = e.currentTarget.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;
    const angle = Math.atan2(e.clientY - centerY, e.clientX - centerX) * 180 / Math.PI;
    const newRotation = angle + 90;
    
    setRotation(newRotation);
    
    // Auto-tune to next station
    const currentIndex = stations.findIndex(s => s.stationuuid === currentStation?.stationuuid);
    const nextIndex = (currentIndex + 1) % stations.length;
    onStationSelect(stations[nextIndex]);
  };

  const generateFrequency = () => {
    if (!currentStation) return "88.0";
    // Generate a realistic FM frequency based on station name hash
    const hash = currentStation.name.split('').reduce((a, b) => a + b.charCodeAt(0), 0);
    const frequency = 88 + (hash % 200) / 10;
    return frequency.toFixed(1);
  };

  return (
    <div className="flex flex-col items-center space-y-4">
      {/* Station Display */}
      <div className="bg-vintage-black rounded-lg p-4 w-full max-w-sm border-4 border-brass-dark shadow-inner">
        <div className={`bg-amber-dark rounded p-3 transition-all duration-500 ${isPowered && currentStation ? 'animate-glow' : 'opacity-50'}`}>
          <div className="text-center">
            <div className="font-orbitron text-vintage-black font-bold text-lg truncate">
              {isPowered && currentStation ? currentStation.name : "-- OFF --"}
            </div>
            <div className="font-orbitron text-vintage-black text-sm mt-1">
              {isPowered && currentStation 
                ? `${currentStation.country}${currentStation.tags && currentStation.tags.length > 0 ? ` • ${currentStation.tags[0]}` : ''}`
                : "Power On Radio"
              }
            </div>
          </div>
        </div>
      </div>

      {/* Tuning Dial */}
      <div className="relative w-48 h-48">
        <div className="absolute inset-0 bg-gradient-to-br from-brass-light to-brass-dark rounded-full shadow-2xl border-8 border-vintage-black">
          {/* Frequency Markings */}
          <div className="absolute inset-4 rounded-full">
            <div className="absolute inset-0">
              <div className="absolute top-2 left-1/2 transform -translate-x-1/2 text-vintage-black text-xs font-bold">88</div>
              <div className="absolute bottom-2 left-1/2 transform -translate-x-1/2 text-vintage-black text-xs font-bold">108</div>
              <div className="absolute left-2 top-1/2 transform -translate-y-1/2 text-vintage-black text-xs font-bold">92</div>
              <div className="absolute right-2 top-1/2 transform -translate-y-1/2 text-vintage-black text-xs font-bold">104</div>
            </div>
          </div>
          
          {/* Tuning Knob */}
          <div 
            className={`absolute inset-8 bg-gradient-to-br from-amber-light to-amber-dark rounded-full shadow-lg border-4 border-brass-dark transition-all duration-300 ${
              isPowered ? 'cursor-pointer transform hover:scale-105' : 'opacity-50 cursor-not-allowed'
            }`}
            style={{ transform: `rotate(${rotation}deg)` }}
            onClick={handleDialClick}
          >
            <div className="absolute inset-2 bg-gradient-to-tl from-amber-dark to-amber-light rounded-full shadow-inner">
              <div className="absolute top-2 left-1/2 w-1 h-8 bg-vintage-black rounded-full transform -translate-x-1/2"></div>
            </div>
          </div>
        </div>
      </div>

      {/* Frequency Display */}
      <div className="bg-vintage-black rounded px-4 py-2 border-2 border-brass-dark">
        <span className={`font-orbitron font-bold text-xl transition-colors ${
          isPowered ? 'text-amber-light' : 'text-gray-600'
        }`}>
          {isPowered ? `${generateFrequency()} MHz` : "-- MHz"}
        </span>
      </div>
    </div>
  );
}
