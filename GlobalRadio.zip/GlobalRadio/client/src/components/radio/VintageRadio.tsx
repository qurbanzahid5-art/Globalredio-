import { useState } from "react";
import { useRadioPlayer } from "@/hooks/useRadioPlayer";
import { useRadioStations } from "@/hooks/useRadioStations";
import { RadioControls } from "./RadioControls";
import { TuningDial } from "./TuningDial";
import { StationList } from "./StationList";
import { Country } from "@/types/radio";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

const COUNTRIES: Country[] = [
  { code: "PK", name: "Pakistan" },
  { code: "IN", name: "India" },
  { code: "US", name: "United States" },
  { code: "GB", name: "United Kingdom" },
  { code: "DE", name: "Germany" },
  { code: "FR", name: "France" },
  { code: "CA", name: "Canada" },
  { code: "AU", name: "Australia" },
  { code: "BR", name: "Brazil" },
  { code: "JP", name: "Japan" },
];

export function VintageRadio() {
  const [selectedCountry, setSelectedCountry] = useState("PK");
  const { 
    audioRef, 
    radioState, 
    selectStation, 
    selectNextStation,
    selectPreviousStation,
    playStation, 
    stopStation, 
    setVolume, 
    togglePower 
  } = useRadioPlayer();

  const { data: stations = [], isLoading } = useRadioStations(selectedCountry);

  const handlePlay = () => {
    if (radioState.isPlaying) {
      stopStation();
    } else {
      playStation();
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-cream to-yellow-50 p-4">
      {/* Header */}
      <header className="text-center mb-8">
        <h1 className="font-fredoka text-4xl md:text-6xl text-walnut-dark mb-2">
          <span className="mr-3">📻</span>
          Vintage FM Radio
        </h1>
        <p className="text-vintage-black text-lg">Pakistan • India • Worldwide Stations</p>
      </header>

      <div className="max-w-4xl mx-auto">
        {/* Radio Housing */}
        <div 
          className="relative bg-gradient-to-br from-walnut-light to-walnut-dark rounded-3xl p-8 shadow-2xl border-4 border-brass-dark"
          style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg width='100' height='100' xmlns='http://www.w3.org/2000/svg'%3E%3Cdefs%3E%3Cpattern id='wood' x='0' y='0' width='100' height='100' patternUnits='userSpaceOnUse'%3E%3Cpath d='M0,50 Q25,40 50,50 T100,50' stroke='%23654321' stroke-width='0.5' fill='none'/%3E%3Cpath d='M0,25 Q25,15 50,25 T100,25' stroke='%23654321' stroke-width='0.3' fill='none'/%3E%3Cpath d='M0,75 Q25,65 50,75 T100,75' stroke='%23654321' stroke-width='0.3' fill='none'/%3E%3C/pattern%3E%3C/defs%3E%3Crect width='100' height='100' fill='url(%23wood)'/%3E%3C/svg%3E")`,
            backgroundSize: "200px 200px"
          }}
        >
          {/* Brand Label */}
          <div className="text-center mb-6">
            <div className="inline-block bg-brass-light px-6 py-2 rounded-lg shadow-inner border-2 border-brass-dark">
              <span className="font-orbitron text-vintage-black font-bold text-xl">VINTAGE RADIO</span>
            </div>
          </div>

          {/* Main Radio Interface */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-center">
            {/* Left Controls */}
            <div>
              <RadioControls
                isPlaying={radioState.isPlaying}
                isPowered={radioState.isPowered}
                volume={radioState.volume}
                isLoading={radioState.isLoading}
                onPlay={handlePlay}
                onStop={stopStation}
                onVolumeChange={setVolume}
                onPowerToggle={togglePower}
                onNextStation={() => selectNextStation(stations)}
                onPreviousStation={() => selectPreviousStation(stations)}
              />
            </div>

            {/* Center Tuning Dial */}
            <div>
              <TuningDial
                stations={stations}
                currentStation={radioState.currentStation}
                onStationSelect={selectStation}
                isPowered={radioState.isPowered}
              />
            </div>

            {/* Right Controls */}
            <div className="space-y-6">
              {/* Country Selector */}
              <div>
                <label className="block text-cream font-bold mb-2">COUNTRY</label>
                <Select value={selectedCountry} onValueChange={setSelectedCountry} disabled={!radioState.isPowered}>
                  <SelectTrigger className="w-full bg-brass-light border-2 border-brass-dark text-vintage-black font-bold">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {COUNTRIES.map((country) => (
                      <SelectItem key={country.code} value={country.code}>
                        {country.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          {/* Station List */}
          <div className="mt-8">
            <h3 className="text-cream font-bold text-xl mb-4 text-center">Available Stations</h3>
            <StationList
              stations={stations}
              currentStation={radioState.currentStation}
              onStationSelect={selectStation}
              isLoading={isLoading}
              isPowered={radioState.isPowered}
            />
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="text-center mt-12 text-vintage-black">
        <p className="text-sm">
          ❤️ Vintage Radio Experience • Powered by Radio Browser API
        </p>
        <p className="text-xs mt-2 opacity-75">Real FM stations from Pakistan, India & worldwide</p>
      </footer>

      {/* Audio Element */}
      <audio ref={audioRef} preload="none" />
    </div>
  );
}
