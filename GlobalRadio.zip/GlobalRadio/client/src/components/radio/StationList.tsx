import { RadioStation } from "@/types/radio";
import { ScrollArea } from "@/components/ui/scroll-area";

interface StationListProps {
  stations: RadioStation[];
  currentStation: RadioStation | null;
  onStationSelect: (station: RadioStation) => void;
  isLoading: boolean;
  isPowered: boolean;
}

export function StationList({ 
  stations, 
  currentStation, 
  onStationSelect, 
  isLoading,
  isPowered 
}: StationListProps) {
  if (isLoading) {
    return (
      <div className="bg-vintage-black rounded-lg p-4 border-4 border-brass-dark">
        <div className="flex items-center justify-center space-x-3 py-8">
          <div className="animate-spin text-brass-light">⚡</div>
          <span className="font-orbitron text-brass-light font-bold">Scanning Frequencies...</span>
        </div>
      </div>
    );
  }

  if (!isPowered) {
    return (
      <div className="bg-vintage-black rounded-lg p-4 border-4 border-brass-dark opacity-50">
        <div className="text-center py-8">
          <span className="font-orbitron text-gray-600 font-bold">Radio Powered Off</span>
        </div>
      </div>
    );
  }

  if (stations.length === 0) {
    return (
      <div className="bg-vintage-black rounded-lg p-4 border-4 border-brass-dark">
        <div className="text-center py-8">
          <span className="font-orbitron text-brass-light font-bold">No Stations Found</span>
          <p className="text-cream text-sm mt-2">Try selecting a different country</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-vintage-black rounded-lg p-4 border-4 border-brass-dark">
      <ScrollArea className="h-64">
        <div className="space-y-2">
          {stations.map((station) => (
            <div
              key={station.stationuuid}
              onClick={() => onStationSelect(station)}
              className={`p-3 rounded cursor-pointer transition-all duration-200 border ${
                currentStation?.stationuuid === station.stationuuid
                  ? 'bg-amber-light border-amber-dark'
                  : 'bg-brass-light hover:bg-brass-dark border-brass-dark'
              }`}
            >
              <div className="flex justify-between items-center">
                <div className="flex-1 min-w-0">
                  <div className="font-bold text-vintage-black truncate">
                    {station.name || 'Unknown Station'}
                  </div>
                  <div className="text-sm text-gray-700 truncate">
                    {Array.isArray(station.tags) && station.tags.length > 0 
                      ? station.tags.slice(0, 2).join(', ') 
                      : station.tags || 'Music'
                    }
                  </div>
                </div>
                <div className="text-right ml-2 flex-shrink-0">
                  <div className="text-sm font-bold text-vintage-black">
                    {station.country || 'Unknown'}
                  </div>
                  <div className="text-xs text-gray-600">
                    {station.bitrate || 128} kbps
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </ScrollArea>
    </div>
  );
}
