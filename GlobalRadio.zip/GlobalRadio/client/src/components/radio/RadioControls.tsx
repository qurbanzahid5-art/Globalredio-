import { useState, useEffect } from "react";
import { Volume2, VolumeX, Power, Play, Pause, Square, SkipForward, SkipBack } from "lucide-react";

interface RadioControlsProps {
  isPlaying: boolean;
  isPowered: boolean;
  volume: number;
  isLoading: boolean;
  onPlay: () => void;
  onStop: () => void;
  onVolumeChange: (volume: number) => void;
  onPowerToggle: () => void;
  onNextStation: () => void;
  onPreviousStation: () => void;
}

export function RadioControls({
  isPlaying,
  isPowered,
  volume,
  isLoading,
  onPlay,
  onStop,
  onVolumeChange,
  onPowerToggle,
  onNextStation,
  onPreviousStation
}: RadioControlsProps) {
  const [volumeKnobRotation, setVolumeKnobRotation] = useState(0);

  useEffect(() => {
    const rotation = (volume / 100) * 270 - 135;
    setVolumeKnobRotation(rotation);
  }, [volume]);

  const handleVolumeKnobClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!isPowered) return;

    const rect = e.currentTarget.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;
    const angle = Math.atan2(e.clientY - centerY, e.clientX - centerX) * 180 / Math.PI;
    const rotation = angle + 90;
    
    setVolumeKnobRotation(rotation);
    
    // Convert rotation to volume (0-100)
    const newVolume = Math.max(0, Math.min(100, (rotation + 135) / 270 * 100));
    onVolumeChange(newVolume);
  };

  return (
    <div className="space-y-6">
      {/* Volume Knob */}
      <div className="text-center">
        <label className="block text-cream font-bold mb-2">VOLUME</label>
        <div className="relative w-24 h-24 mx-auto">
          <div className="absolute inset-0 bg-gradient-to-br from-brass-light to-brass-dark rounded-full shadow-lg border-4 border-amber-dark">
            <div className="absolute inset-2 bg-gradient-to-tl from-brass-dark to-brass-light rounded-full shadow-inner">
              <div 
                className={`absolute inset-3 bg-vintage-black rounded-full transition-all duration-200 ${
                  isPowered ? 'cursor-pointer transform hover:scale-105' : 'opacity-50 cursor-not-allowed'
                }`}
                style={{ transform: `rotate(${volumeKnobRotation}deg)` }}
                onClick={handleVolumeKnobClick}
              >
                <div className="absolute top-1 left-1/2 w-1 h-4 bg-amber-light rounded-full transform -translate-x-1/2"></div>
              </div>
            </div>
          </div>
        </div>
        <input 
          type="range" 
          min="0" 
          max="100" 
          value={volume} 
          onChange={(e) => onVolumeChange(parseInt(e.target.value))}
          className="w-full mt-2 opacity-0 absolute"
          disabled={!isPowered}
        />
        <div className="text-cream text-xs mt-1">{isPowered ? volume : 0}%</div>
      </div>

      {/* Power Button */}
      <div className="text-center">
        <button 
          onClick={onPowerToggle}
          className={`w-16 h-16 rounded-full shadow-lg border-4 transition-all duration-200 relative group ${
            isPowered 
              ? 'bg-gradient-to-br from-red-500 to-red-700 border-red-800 hover:from-red-400 hover:to-red-600' 
              : 'bg-gradient-to-br from-gray-500 to-gray-700 border-gray-800 hover:from-gray-400 hover:to-gray-600'
          }`}
        >
          <Power className="text-white text-xl mx-auto" size={20} />
          <div className="absolute -bottom-8 left-1/2 transform -translate-x-1/2 text-cream text-sm font-bold opacity-0 group-hover:opacity-100 transition-opacity">
            POWER
          </div>
        </button>
      </div>

      {/* Control Buttons */}
      <div className="grid grid-cols-4 gap-2">
        {/* Previous Station */}
        <button 
          onClick={onPreviousStation}
          disabled={!isPowered}
          className={`bg-gradient-to-br from-blue-500 to-blue-700 hover:from-blue-400 hover:to-blue-600 text-white p-3 rounded-lg shadow-lg border-2 border-blue-800 transition-all duration-200 font-bold ${
            !isPowered ? 'opacity-50 cursor-not-allowed' : ''
          }`}
        >
          <SkipBack className="mx-auto" size={16} />
          <div className="text-xs mt-1">PREV</div>
        </button>

        {/* Play/Pause */}
        <button 
          onClick={onPlay}
          disabled={!isPowered || isLoading}
          className={`p-3 rounded-lg shadow-lg border-2 transition-all duration-200 font-bold ${
            isPlaying && isPowered
              ? 'bg-gradient-to-br from-yellow-500 to-yellow-700 border-yellow-800 text-white animate-glow'
              : 'bg-gradient-to-br from-green-500 to-green-700 border-green-800 text-white hover:from-green-400 hover:to-green-600'
          } ${(!isPowered || isLoading) ? 'opacity-50 cursor-not-allowed' : ''}`}
        >
          {isLoading ? (
            <div className="animate-spin mx-auto">⚡</div>
          ) : isPlaying ? (
            <Pause className="mx-auto" size={16} />
          ) : (
            <Play className="mx-auto" size={16} />
          )}
          <div className="text-xs mt-1">{isPlaying ? 'PAUSE' : 'PLAY'}</div>
        </button>
        
        {/* Stop */}
        <button 
          onClick={onStop}
          disabled={!isPowered}
          className={`bg-gradient-to-br from-red-500 to-red-700 hover:from-red-400 hover:to-red-600 text-white p-3 rounded-lg shadow-lg border-2 border-red-800 transition-all duration-200 font-bold ${
            !isPowered ? 'opacity-50 cursor-not-allowed' : ''
          }`}
        >
          <Square className="mx-auto" size={16} />
          <div className="text-xs mt-1">STOP</div>
        </button>

        {/* Next Station */}
        <button 
          onClick={onNextStation}
          disabled={!isPowered}
          className={`bg-gradient-to-br from-blue-500 to-blue-700 hover:from-blue-400 hover:to-blue-600 text-white p-3 rounded-lg shadow-lg border-2 border-blue-800 transition-all duration-200 font-bold ${
            !isPowered ? 'opacity-50 cursor-not-allowed' : ''
          }`}
        >
          <SkipForward className="mx-auto" size={16} />
          <div className="text-xs mt-1">NEXT</div>
        </button>
      </div>

      {/* Band Selection */}
      <div className="text-center">
        <label className="block text-cream font-bold mb-2">BAND</label>
        <div className="flex justify-center space-x-2">
          <button className="bg-brass-light hover:bg-brass-dark text-vintage-black px-3 py-2 rounded font-bold text-sm border-2 border-brass-dark transition-colors">
            FM
          </button>
          <button className="bg-gray-400 text-vintage-black px-3 py-2 rounded font-bold text-sm border-2 border-gray-600 opacity-50 cursor-not-allowed">
            AM
          </button>
        </div>
      </div>
    </div>
  );
}
